# -*- coding: utf-8 -*-

DEBUG = True

SECRET_KEY = 'A0Zr98j/3yX R~XHH!jmN]LWX/,?RT'