# -*- coding: utf-8 -*-

from blog import app


if __name__ == '__main__':
    app.run(host='192.168.1.101')
