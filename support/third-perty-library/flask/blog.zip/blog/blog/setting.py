# _*_ coding: utf-8 _*_

#调试模式是否开启
DEBUG = True

REDIS_URL = "redis://192.168.1.101:6379/0"

#session必须要设置key
SECRET_KEY = 'A0Zr98j/3yX R~XHH!jmN]LWX/,?RT'
